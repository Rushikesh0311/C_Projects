void populateAddressBook(struct AddressBook* addressBook);
